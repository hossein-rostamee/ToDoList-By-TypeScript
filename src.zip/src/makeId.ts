let id = 0
const makeId = () => ++id
export default makeId